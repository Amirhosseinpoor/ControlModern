% Main script for comparing NONLINEAR vs. LINEAR open-loop simulations
clear; clc; close all;

% --- System Parameters ---
m = 0.111;      % Mass of the ball (kg)
R = 0.015;      % Radius of the ball (m)
g = 9.8;        % Acceleration due to gravity (m/s^2)
J = 9.99e-6;    % Moment of inertia of the ball (kg*m^2)
L = 1.0;
d = 0.03;

% --- Simulation Setup ---
model_name = 'ball'; % Your Simulink file name
t_stop = 2.5;        % Simulation stop time

% --- Define the four initial condition sets ---
initial_conditions = {
    [0; 0],     % 1. Start from rest at the center (the linearization point)
    [0.2; 0],   % 2. Start at r=0.2, rest
    [0; 0.25],  % 3. Start at the center with an "uphill" velocity
    [0.1; 0.1]  % 4. Start at a positive position with an "uphill" velocity
};

fprintf('Linearizing Simulink model "%s"...\n', model_name);
[A, B, C, D] = linmod(model_name);
sys_ss = ss(A, B, C, D);
fprintf('Linearization complete. System matrices [A,B,C,D] created.\n\n');

num_sims = length(initial_conditions);
nonlinear_results = cell(1, num_sims);
linear_results = cell(1, num_sims);

% --- FIX: Define an EVENLY SPACED time vector for the linear simulation ---
t_linear = (0:0.01:t_stop)'; % Use a 0.01s step size. The transpose (') makes it a column vector.

fprintf('Starting nonlinear and linear simulations...\n');
for i = 1:num_sims
    current_x0 = initial_conditions{i};
    pos_ic = current_x0(1);
    vel_ic = current_x0(2);
    
    fprintf('Running Sim #%d with r(0)=%.2f, r_dot(0)=%.2f\n', i, pos_ic, vel_ic);
    
    % --- Run Nonlinear Simulink Simulation ---
    set_param([model_name, '/Integrator_Pos'], 'InitialCondition', num2str(pos_ic));
    set_param([model_name, '/Integrator_Vel'], 'InitialCondition', num2str(vel_ic));
    simOut = sim(model_name, 'StopTime', num2str(t_stop));
    nonlinear_results{i} = simOut.yout{1}; 
    
    % --- Run Linear System Simulation ---
    % --- FIX: Use the new, evenly spaced time vector ---
    [y_linear, t_out, x_linear] = initial(sys_ss, current_x0, t_linear);
    
    linear_results{i}.Time = t_out;
    linear_results{i}.Data = y_linear;
end
fprintf('All simulations finished.\n\n');

figure('Name', 'Nonlinear vs. Linear Dynamic Response', 'Position', [100, 100, 900, 700]);
line_colors = {'b', 'r', 'g', 'k'};
plot_legends = {
    'r(0)=0, r_{dot}(0)=0', ...
    'r(0)=0.2, rest', ...
    'r(0)=0, r_{dot}(0)=0.25', ...
    'r(0)=0.1, r_{dot}(0)=0.1'
    };

hold on;
for i = 1:num_sims
    % Plot Nonlinear (Simulink) result as a solid line
    plot(nonlinear_results{i}.Values.Time, nonlinear_results{i}.Values.Data, ...
        [line_colors{i}, '-'], 'LineWidth', 2.5, 'DisplayName', ['Nonlinear: ' plot_legends{i}]);
        
    % Plot Linear (State-Space) result as a dashed line
    plot(linear_results{i}.Time, linear_results{i}.Data, ...
        [line_colors{i}, '--'], 'LineWidth', 1.5, 'DisplayName', ['Linear:    ' plot_legends{i}]);
end
hold off;

% --- Formatting ---
title('Comparison: Nonlinear (Simulink) vs. Linear (State-Space) Response');
xlabel('Time (s)');
ylabel('Ball Position r (m)');
grid on;
legend('Location', 'northwest');
ylim([-0.5, 1.0]);