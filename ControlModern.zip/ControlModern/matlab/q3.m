% Define the constants
m = 0.111;
R = 0.015;
g = -9.8;
L = 1.0;
d = 0.03;
J = 9.99e-6;

% Define the transfer function variable 's'
s = tf('s');

% Define the transfer function of the system
P_ball = -m*g*d/L/(J/R^2+m)/s^2;

% Create a time vector for the ramp response simulation
t = 0:0.01:2;

% Create a new figure
figure;

% 1. Impulse Response
subplot(3,1,1);
impulse(P_ball);
title('Impulse Response');
grid on;

% 2. Step Response
subplot(3,1,2);
step(P_ball);
title('Step Response');
grid on;

% 3. Ramp Response
subplot(3,1,3);
lsim(P_ball, t, t);
title('Ramp Response');
grid on;