%% Main Script to Design and Test a State-Feedback Tracker
% Clean up the environment
clear; 
clc; 
close all;

% --- 1. System and Model Definition ---
% This section is unchanged.
fprintf('Defining the ball and beam system...\n');
% Physical parameters
m = 0.111;      % Mass of the ball (kg)
R = 0.015;      % Radius of the ball (m)
g = -9.8;       % Acceleration due to gravity (m/s^2)
J = 9.99e-6;    % Ball's moment of inertia (kg*m^2)
H = -m*g / (J/(R^2) + m);
% State-Space matrices
A = [0 1 0 0;
     0 0 H 0;
     0 0 0 1;
     0 0 0 0];
B = [0; 0; 0; 1];
C = [1 0 0 0];
D = [0];
% Create a state-space object for the system
ball_ss = ss(A, B, C, D);

% --- 2. Controller Design (Following the Theory) ---
% This section is unchanged. The controller is designed once.
fprintf('Designing the state-feedback tracker...\n');
% Choose desired closed-loop poles for stability and performance.
poles = [-2+2i, -2-2i, -20, -80]; % A balanced, stable design
% Calculate the state-feedback gain K using pole placement.
K = place(A, B, poles);
fprintf('Calculated Feedback Gain K:\n');
disp(K);
% Calculate the feedforward pre-compensator gain, Nbar.
Nbar = calculate_Nbar(ball_ss, K);
fprintf('Calculated Pre-compensator Gain Nbar = %.4f\n', Nbar);

% --- 3. Simulation of the Complete Closed-Loop Tracker ---
% This is the only modified section. We now create a multi-step input.
fprintf('Simulating the tracker with multiple sequential inputs...\n');

% Define simulation time to accommodate three steps
t = 0:0.01:20; 

% Create a reference signal with three different step commands
ref_input = zeros(size(t)); % Initialize the input vector
ref_input(t >= 1 & t < 8) = 0.15;  % First command: move to 0.15m
ref_input(t >= 8 & t < 15) = 0.30; % Second command: move to 0.30m
ref_input(t >= 15) = 0.10;         % Third command: move back down to 0.10m

% Create the complete closed-loop system using the derived control law.
% This system definition is the same as before.
sys_cl = ss(A - B*K, B*Nbar, C, D);

% Run the simulation with the new multi-step reference signal.
[y, t_out, x] = lsim(sys_cl, ref_input, t);

% --- 4. Plotting the Results ---
% The plotting logic is unchanged, but will now show the new response.
fprintf('Plotting the results...\n');
figure('Name', 'Multi-Step Reference Tracker Performance');
plot(t, y, 'b', 'LineWidth', 2);
hold on;

% Plot the multi-step reference line to see how well we are tracking
plot(t, ref_input, 'r:', 'LineWidth', 2.5);
hold off;

title('Response to Multiple Step Commands');
xlabel('Time (seconds)');
ylabel('Ball Position (meters)');
grid on;
legend('Actual Ball Position (y)', 'Desired Reference (r)', 'Location', 'best');
axis([0 20 -0.05 0.35]); % Adjust axis limits for the new simulation

%% --- Required Function for Calculating Nbar ---
% This function is unchanged.
function [Nbar] = calculate_Nbar(sys, K)
    [A, B, C, D] = ssdata(sys);
    dc_gain = -C * inv(A - B*K) * B;
    Nbar = inv(dc_gain);
end