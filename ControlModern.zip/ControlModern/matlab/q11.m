%% Main Script to Design and Test a Tracker with Integral Control
% This version tests the controller with a multi-step reference signal.

% Clean up the environment
clear;
clc;
close all;

% --- 1. System and Model Definition ---
fprintf('Defining the ball and beam system...\n');
% Physical parameters
m = 0.111;      % Mass of the ball (kg)
R = 0.015;      % Radius of the ball (m)
g = -9.8;       % Acceleration due to gravity (m/s^2)
J = 9.99e-6;    % Ball's moment of inertia (kg*m^2)
H = -m*g / (J/(R^2) + m);
% State-Space matrices (4th order system, n=4)
A = [0 1 0 0;
     0 0 H 0;
     0 0 0 1;
     0 0 0 0];
B = [0; 0; 0; 1];
C = [1 0 0 0];
D = [0];
n = size(A, 1); % Number of states

% --- 2. Integral Controller Design ---
% This section is unchanged. The controller is designed once.
fprintf('Designing the tracker with integral action...\n');

% Step 1: Form the Augmented System (5th order system, n+1)
Aa = [A, zeros(n, 1);
      -C, 0];
Ba = [B; 0];

% Step 2: Check for Controllability of the Augmented System
controllability_matrix = [A, B; -C, 0];
rank_M = rank(controllability_matrix);
fprintf('The rank of the controllability matrix is %d.\n', rank_M);
if rank_M < (n + 1)
    error('System is not controllable with integral action. Design cannot proceed.');
else
    fprintf('The augmented system is controllable. Proceeding with design.\n');
end

% Step 3: Choose desired poles for the 5th order augmented system.
poles_a = [-1.5, -2+2i, -2-2i, -20, -80];

% Step 3b: Calculate the augmented feedback gain Ka using pole placement.
Ka = place(Aa, Ba, poles_a);
fprintf('Calculated Augmented Feedback Gain Ka:\n');
disp(Ka);

% --- 3. Simulation of the Complete Closed-Loop System ---
% This section is updated with the requested multi-step input.
fprintf('Simulating the tracker with multiple sequential inputs...\n');

% Define simulation time to accommodate the sequence
t = 0:0.01:20;

% Create the reference signal with three different step commands as requested
ref_input = zeros(size(t)); % Initialize the input vector
ref_input(t >= 1 & t < 8) = 0.15;  % First command: move to 0.15m
ref_input(t >= 8 & t < 15) = 0.30; % Second command: move to 0.30m
ref_input(t >= 15) = 0.10;         % Third command: move back down to 0.10m

% Form the final closed-loop system (this part is unchanged)
A_cl = Aa - Ba*Ka;
B_cl = [zeros(n,1); 1]; % Input is the reference r
C_cl = [C, 0];          % Output is still the original y
D_cl = 0;

sys_cl = ss(A_cl, B_cl, C_cl, D_cl);

% Run the simulation with the new multi-step reference signal
[y, t_out] = lsim(sys_cl, ref_input, t);

% --- 4. Plotting the Results ---
fprintf('Plotting the results...\n');
figure('Name', 'Integral Control Tracker Performance');
plot(t_out, y, 'b', 'LineWidth', 2);
hold on;
plot(t_out, ref_input, 'r:', 'LineWidth', 2.5);
hold off;

title('Response to Multiple Step Commands (Integral Control)');
xlabel('Time (seconds)');
ylabel('Ball Position (meters)');
grid on;
legend('Actual Ball Position (y)', 'Desired Reference (r)', 'Location', 'best');
axis([0 20 -0.05 0.35]); % Adjust axis for the new simulation time