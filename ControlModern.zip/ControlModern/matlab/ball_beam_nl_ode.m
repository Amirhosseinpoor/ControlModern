
function dxdt = ball_beam_nl_ode(t, x, params)
    % Unpack parameters
    m = params.m;
    R = params.R;
    g = params.g;
    J = params.J;
    
    % --- DYNAMIC CONDITION ---
    % The beam is held at a fixed, non-zero angle (e.g., 0.05 radians).
    % This makes the system dynamic as gravity will now accelerate the ball.
    alpha = 0.05;      % Fixed beam angle in radians (approx. 2.8 degrees)
    alpha_dot = 0;     % The beam angle is not changing
    
    % State variables
    r = x(1);
    r_dot = x(2);
    
    % Nonlinear equation for r_ddot
    % The term '-m*g*sin(alpha)' is now a constant non-zero force
    r_ddot = (m * r * alpha_dot^2 - m * g * sin(alpha)) / (J/R^2 + m);
    
    % State derivatives
    dxdt = zeros(2,1);
    dxdt(1) = r_dot;
    dxdt(2) = r_ddot;
end