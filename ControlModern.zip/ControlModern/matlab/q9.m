%% Main Script to Analyze Pole Placement Effects

% Clean up the environment
clear; 
clc; 
close all;

% --- 1. System and Model Definition ---
fprintf('Defining the ball and beam system...\n');

% Physical parameters for the ball and beam system
m = 0.111;      % Mass of the ball (kg)
R = 0.015;      % Radius of the ball (m)
g = -9.8;       % Acceleration due to gravity (m/s^2)
J = 9.99e-6;    % Ball's moment of inertia (kg*m^2)

% Calculate intermediate constant H based on physical parameters
H = -m*g / (J/(R^2) + m);

% State-Space matrices [x_dot = Ax + Bu, y = Cx + Du]
% State vector x = [ball_position; ball_velocity; beam_angle; beam_velocity]
A = [0 1 0 0;
     0 0 H 0;
     0 0 0 1;
     0 0 0 0];
B = [0; 0; 0; 1];
C = [1 0 0 0];
D = [0];

% Create a state-space object for the system
ball_ss = ss(A, B, C, D);


% --- 2. Controller Design for Different Pole Locations ---
fprintf('Designing four different state-feedback controllers...\n');

% Define the pole locations for each scenario
poles_orig = [-2+2i, -2-2i, -20, -80];       % Original balanced design
poles_fast = [-4+4i, -4-4i, -20, -80];       % Faster response design
poles_damped = [-2, -3, -20, -80];           % Overdamped (no overshoot) design
poles_oscillate = [-2+4i, -2-4i, -20, -80];  % Underdamped (more overshoot) design

% Calculate feedback gain K and feed-forward scaling Nbar for each case
K_orig = place(A, B, poles_orig);
Nbar_orig = rscale(ball_ss, K_orig);

K_fast = place(A, B, poles_fast);
Nbar_fast = rscale(ball_ss, K_fast);

K_damped = place(A, B, poles_damped);
Nbar_damped = rscale(ball_ss, K_damped);

K_oscillate = place(A, B, poles_oscillate);
Nbar_oscillate = rscale(ball_ss, K_oscillate);


% --- 3. Simulation of Closed-Loop Systems ---
fprintf('Simulating step response for each controller...\n');

% Define simulation time and the reference step input (a desired position of 0.25m)
t = 0:0.01:5;
ref_input = 0.25 * ones(size(t));

% Create the four closed-loop systems with the scaling factor Nbar applied
sys_cl_orig = ss(A - B*K_orig, B*Nbar_orig, C, D);
sys_cl_fast = ss(A - B*K_fast, B*Nbar_fast, C, D);
sys_cl_damped = ss(A - B*K_damped, B*Nbar_damped, C, D);
sys_cl_oscillate = ss(A - B*K_oscillate, B*Nbar_oscillate, C, D);

% Run the simulation for each system
[y_orig, ~] = lsim(sys_cl_orig, ref_input, t);
[y_fast, ~] = lsim(sys_cl_fast, ref_input, t);
[y_damped, ~] = lsim(sys_cl_damped, ref_input, t);
[y_oscillate, ~] = lsim(sys_cl_oscillate, ref_input, t);


% --- 4. Plotting the Comparative Results ---
fprintf('Plotting the results...\n');

figure('Name', 'Pole Placement Effects');
hold on;

% Plot each response with a unique line style for clarity
plot(t, y_orig, 'k', 'LineWidth', 2);
plot(t, y_fast, 'r--', 'LineWidth', 1.5);
plot(t, y_damped, 'b-.', 'LineWidth', 1.5);
plot(t, y_oscillate, 'g:', 'LineWidth', 2);
plot(t, ref_input, 'Color', [0.5 0.5 0.5], 'LineStyle', ':', 'DisplayName', 'Reference');

hold off;

% Add labels, title, grid, and legend to the plot
title('Effect of Pole Placement on System Response');
xlabel('Time (seconds)');
ylabel('Ball Position (meters)');
grid on;
legend('Original [-2\pm2i]', ...
       'Faster [-4\pm4i]', ...
       'More Damped [-2, -3]', ...
       'Less Damped [-2\pm4i]', ...
       'Location', 'best');
axis([0 5 0 0.35]); % Set axis limits for a better view


%% --- Required Function ---
% This function must be in the same directory as the script, or at the end
% of the script file as it is here (for MATLAB R2016b and newer).

function [Nbar] = rscale(sys, K)
    % Extracts A, B, C, D matrices from the system object
    [A, B, C, D] = ssdata(sys);
    
    % Solves for the scale factor Nbar to eliminate steady-state error
    s = size(A, 1);
    Z = [zeros(1, s), 1];
    N_matrix = inv([A, B; C, D]) * Z';
    Nx = N_matrix(1:s);
    Nu = N_matrix(s+1);
    
    Nbar = Nu + K * Nx;
end