% File: simulate_input_response.m
clear; clc; close all;

% تعریف پارامترهای فیزیکی سیستم (مشابه قبل)
params.m = 0.11;
params.R = 0.015;
params.g = 9.8;
params.L = 1.0;
params.J_ball = 2/5 * params.m * params.R^2;
params.J_beam = 0.02;

% شرایط اولیه (شروع از حالت سکون در مرکز)
x0 = [0,0,0,0];

% بازه زمانی شبیه‌سازی
t_span = [0 5];

% --- شبیه‌سازی برای ورودی پله ---
params_step = params;
params_step.u = -0.1; % گشتاور پله ثابت (مقدار منفی برای مقابله با گرانش اولیه)
[t_step, x_step] = ode45(@(t,x) ball_beam_nonlinear_ode(t, x, params_step), t_span, x0);

% --- شبیه‌سازی برای ورودی ضربه ---
% تعریف ورودی ضربه (پالس کوتاه)
u_impulse_func = @(t) (t >= 0.1 && t <= 0.2) * -1.0; % ضربه با دامنه 1 و مدت 0.1 ثانیه
ode_impulse = @(t,x) ball_beam_nonlinear_ode(t, x, struct('m', params.m, 'R', params.R, 'g', params.g, 'J_ball', params.J_ball, 'J_beam', params.J_beam, 'u', u_impulse_func(t)));
[t_impulse, x_impulse] = ode45(ode_impulse, t_span, x0);

% --- شبیه‌سازی برای ورودی شیب ---
% تعریف ورودی شیب
u_ramp_func = @(t) -0.05 * t; % شیب با ضریب 0.05
ode_ramp = @(t,x) ball_beam_nonlinear_ode(t, x, struct('m', params.m, 'R', params.R, 'g', params.g, 'J_ball', params.J_ball, 'J_beam', params.J_beam, 'u', u_ramp_func(t)));
[t_ramp, x_ramp] = ode45(ode_ramp, t_span, x0);

% رسم نتایج
figure('Name', 'Nonlinear System Response to Various Inputs');
subplot(2,1,1);
plot(t_step, x_step(:,1), 'b-', 'LineWidth', 1.5); hold on;
plot(t_impulse, x_impulse(:,1), 'r--', 'LineWidth', 1.5);
plot(t_ramp, x_ramp(:,1), 'g-.', 'LineWidth', 1.5);
title('Ball Position (r) for Different Inputs');
xlabel('Time (s)');
ylabel('Position (m)');
legend('Step Input', 'Impulse Input', 'Ramp Input');
grid on;
ylim([-params.L/2, params.L/2]);

subplot(2,1,2);
plot(t_step, x_step(:,3), 'b-', 'LineWidth', 1.5); hold on;
plot(t_impulse, x_impulse(:,3), 'r--', 'LineWidth', 1.5);
plot(t_ramp, x_ramp(:,3), 'g-.', 'LineWidth', 1.5);
title('Beam Angle (\alpha) for Different Inputs');
xlabel('Time (s)');
ylabel('Angle (rad)');
legend('Step Input', 'Impulse Input', 'Ramp Input');
grid on;