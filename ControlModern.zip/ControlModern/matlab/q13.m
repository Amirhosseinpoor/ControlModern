%% Observer-Based Control of a Nonlinear Ball and Beam System (Final Corrected Version)
clear;
clc;
close all;

%% --- Part A: State-Feedback Controller Design ---

fprintf('Step 1: Designing the state-feedback controller (K)...\n');
% System parameters
m = 0.111; R = 0.015; g = 9.8; J = 9.99e-6;
H_const = m*g / (J/(R^2) + m);

% --- KEY CORRECTION ---
% The linearized A matrix must correctly model the nonlinear dynamics.
% The term A(2,3) must be positive, consistent with dx_dt(2) = H*sin(x(3)).
A = [0 1 0 0;
     0 0 H_const 0;  % Corrected sign (was -H_const)
     0 0 0 1;
     0 0 0 0];
B = [0; 0; 0; 1];
C = [1 0 0 0];
n = size(A,1);

% Choose desired poles for the controller
controller_poles = [-2+2i, -2-2i, -20, -80];
K = place(A, B, controller_poles);
fprintf('Controller gain K calculated.\n');

%% --- Part B: Full-Order Observer Design ---

% Step 2: Check system observability
observability_matrix = obsv(A, C);
if rank(observability_matrix) < n
    error('System is not observable. Observer cannot be designed.');
else
    fprintf('Step 2: System is observable.\n');
end

% Step 3 & 4: Choose observer poles and calculate observer gain L
fprintf('Step 3 & 4: Designing the observer (L)...\n');
observer_poles = 4.5 * [-2, -2.2, -2.4, -2.6];
L_T = place(A', C', observer_poles);
L = L_T';
fprintf('Observer gain L calculated.\n');


%% --- Part C: Nonlinear Simulation ---

fprintf('Step 5 & 6: Setting up and running the nonlinear simulation...\n');
t_span = [0 10];
% Use small, non-zero initial conditions
x0 = [-0.1; 0; -0.05; 0]; 
x_hat0 = [0; 0; 0; 0];
X0 = [x0; x_hat0];

% Run the simulation
[t, X_out] = ode45(@(t,X) system_dynamics(t, X, A, B, C, K, L, H_const), t_span, X0);

% Extract states for plotting
x_true = X_out(:, 1:n);
x_est = X_out(:, n+1:end);

fprintf('Simulation complete.\n');

%% --- Plotting the Results ---
figure('Name', 'Stable Observer-Based Control of Nonlinear System');

% Plot 1: Ball Position (x1) vs. its estimate
subplot(2,2,1);
plot(t, x_true(:,1), 'b', 'LineWidth', 2);
hold on;
plot(t, x_est(:,1), 'r--', 'LineWidth', 2);
grid on;
title('Ball Position: True vs. Estimated');
xlabel('Time (s)');
ylabel('Position (m)');
legend('True (x_1)', 'Estimated (\hat{x}_1)');

% Plot 2: Beam Angle (x3) vs. its estimate
subplot(2,2,2);
plot(t, x_true(:,3), 'b', 'LineWidth', 2);
hold on;
plot(t, x_est(:,3), 'r--', 'LineWidth', 2);
grid on;
title('Beam Angle: True vs. Estimated');
xlabel('Time (s)');
ylabel('Angle (rad)');
legend('True (x_3)', 'Estimated (\hat{x}_3)');

% Plot 3: Estimation Error for Position
subplot(2,2,3);
plot(t, x_true(:,1) - x_est(:,1), 'k', 'LineWidth', 2);
grid on;
title('Estimation Error (x_1 - \hat{x}_1)');
xlabel('Time (s)');
ylabel('Error (m)');

% Plot 4: Control Input u(t)
u = -K * x_est';
subplot(2,2,4);
plot(t, u, 'g', 'LineWidth', 2);
grid on;
title('Control Input u(t)');
xlabel('Time (s)');
ylabel('Torque (N·m)');


%% --- Function Defining the Combined System Dynamics ---
function dX_dt = system_dynamics(t, X, A, B, C, K, L, H_const)
    n = size(A,1);
    x = X(1:n);
    x_hat = X(n+1:end);

    % --- Controller ---
    u = -K * x_hat;
    
    % --- Nonlinear Plant Dynamics ---
    dx_dt = zeros(n,1);
    dx_dt(1) = x(2);
    dx_dt(2) = H_const * sin(x(3)); % Nonlinear term
    dx_dt(3) = x(4);
    dx_dt(4) = u;
    
    % --- Observer Dynamics ---
    y = C * x;
    dx_hat_dt = A*x_hat + B*u + L*(y - C*x_hat);

    dX_dt = [dx_dt; dx_hat_dt];
end