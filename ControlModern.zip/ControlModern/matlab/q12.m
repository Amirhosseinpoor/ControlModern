%% Design and Test a Reduced-Order Observer (Corrected for vertcat error)
clear;
clc;
close all;

%% --- System and Controller Definition ---
m = 0.111; R = 0.015; g = -9.8; J = 9.99e-6;
H = -m * g / (J / (R^2) + m);
A = [0 1 0 0; 0 0 H 0; 0 0 0 1; 0 0 0 0];
B = [0; 0; 0; 1];
C = [1 0 0 0];
n = size(A, 1);
l = size(C, 1);

controller_poles = [-2 + 2i, -2 - 2i, -20, -80];
K = place(A, B, controller_poles);
Nk = -1 / (C * inv(A - B * K) * B);

fprintf('Controller gains K and Nk are defined.\n');

%% --- PART A: Reduced-Order Observer Design ---
observer_poles = [-10, -11, -12];
fprintf('Designing a 3rd order observer with poles at: ');
fprintf('%.1f ', observer_poles);
fprintf('\n');

Q = [0 0 0 1; 0 1 0 0; 0 0 1 0; 1 0 0 0];
Q_inv = inv(Q);

A_bar = Q_inv * A * Q;
A11_bar = A_bar(1:n-l, 1:n-l);
A12_bar = A_bar(1:n-l, n-l+1:n);
A21_bar = A_bar(n-l+1:n, 1:n-l);
A22_bar = A_bar(n-l+1:n, n-l+1:n);

L_bar_T = place(A11_bar', A21_bar', observer_poles);
L_bar = L_bar_T';

D_obs = A11_bar - L_bar * A21_bar;
T_obs = A12_bar - L_bar * A22_bar;

L = [eye(n-l), -L_bar] * Q_inv;
R = L * B;

fprintf('Observer matrices L, R, D_obs, T_obs calculated.\n');

%% --- PART B: Simulation and Error Analysis ---

% --- Step 5: Form the Full Observer-Based Control System ---
% This section is now corrected.

% First, calculate the state reconstruction matrices F1 and F2
% x_hat = inv([C; L]) * [y; z], where inv([C;L]) = [F1, F2]
Reconstruction_Matrix = inv([C; L]);
F1 = Reconstruction_Matrix(:, 1:l);
F2 = Reconstruction_Matrix(:, l+1:n);

% Now, form the correct closed-loop matrix A_cl using F2.
% The state is [x; e], where e = z - L*x is the observer error.
% The dynamics are: x_dot = (A - BK)x - B*K*F2*e + B*Nk*r
%                   e_dot = D_obs*e
A_cl = [A - B*K, -B*K*F2;
        zeros(n-l, n), D_obs];

B_cl = [B*Nk;
        zeros(n-l, 1)];

C_cl = [C, zeros(l, n-l)];
D_cl = 0;

sys_cl = ss(A_cl, B_cl, C_cl, D_cl);
fprintf('Full 7th-order closed-loop system created successfully.\n');

% --- Step 6: Simulate and Calculate Tracking Error Norms ---
t = 0:0.01:10;
r = 1; % Unit step reference
[y, t_sim] = step(sys_cl, t);

e_track = r - y;
norm_L2 = sqrt(trapz(t_sim, e_track.^2));
norm_L_inf = max(abs(e_track(t_sim > 0)));

fprintf('\n--- Tracking Error Analysis ---\n');
fprintf('L2 Norm (Error Energy):    %.4f\n', norm_L2);
fprintf('L-inf Norm (Peak Error):   %.4f\n', norm_L_inf);

% --- Plot the Results ---
figure('Name', 'Reduced-Order Observer Performance');
subplot(2,1,1);
plot(t_sim, y, 'b', 'LineWidth', 2);
hold on;
plot(t_sim, ones(size(t_sim)), 'r:', 'LineWidth', 2);
hold off;
title('Step Response with Reduced-Order Observer');
ylabel('Ball Position (y)');
legend('System Output', 'Reference', 'Location', 'best');
grid on;

subplot(2,1,2);
plot(t_sim, e_track, 'k', 'LineWidth', 2);
title('Tracking Error (r - y)');
xlabel('Time (seconds)');
ylabel('Error');
grid on;