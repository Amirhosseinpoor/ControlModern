% Define the constants
	% Main script for DYNAMIC open-loop simulation using Simulink
	clear; clc; close all;
	
	% --- System Parameters ---
	m = 0.111;      % Mass of the ball (kg)
	R = 0.015;      % Radius of the ball (m)
	g = 9.8;        % Acceleration due to gravity (m/s^2)
	J = 9.99e-6;    % Moment of inertia of the ball (kg*m^2)
	L = 1.0;
	d = 0.03;
	
	% --- Simulation Setup ---
	model_name = 'ball'; % نام فایل سیمولینک شما (بدون .slx)
	t_stop = 2.5;        % زمان پایان شبیه‌سازی
	
	% Define the four initial condition sets
	initial_conditions = {
	[0; 0],     % 1. Start from rest at the center
	[0.2; 0],   % 2. Start at r=0.2, rest
	[0; 0.25],  % 3. Start at the center with an "uphill" velocity
	[0.1; 0.1]  % 4. Start at a positive position with an "uphill" velocity
	};
	
	% Prepare to store results
	num_sims = length(initial_conditions);
	results = cell(1, num_sims);
	
	% --- Run Simulations in a Loop ---
	fprintf('Starting simulations for model: %s\n', model_name);
	for i = 1:num_sims
	current_x0 = initial_conditions{i};
	pos_ic = current_x0(1);
	vel_ic = current_x0(2);
	
	fprintf('Running simulation #%d with r(0)=%.2f, r_dot(0)=%.2f\n', i, pos_ic, vel_ic);
	
	set_param([model_name, '/Integrator_Pos'], 'InitialCondition', num2str(pos_ic));
	set_param([model_name, '/Integrator_Vel'], 'InitialCondition', num2str(vel_ic));
	
	simOut = sim(model_name, 'StopTime', num2str(t_stop));
	
	results{i} = simOut.yout{1};
	end
	fprintf('All simulations finished.\n');
	
	% --- Plotting Results ---
	figure('Name', 'Dynamic Response from Simulink');
	hold on;
	line_styles = {'b-', 'r--', 'g:', 'k-.'};
	plot_legends = {
	'Start at rest: r(0)=0,  r_{dot}(0)=0', ...
	'Start at r=0.2, rest', ...
	'Uphill velocity: r_{dot}(0)=0.25', ...
	'Uphill velocity from r=0.1'
	};
	
	for i = 1:num_sims
	plot(results{i}.Values.Time, results{i}.Values.Data, line_styles{i}, 'LineWidth', 2);
	end
	
	hold off;
	
	% --- تنظیم دستی مقیاس محورها ---
	% این دو خط برای بزرگ‌تر کردن مقیاس نمودار اضافه شده‌اند
	xlim([0 t_stop + 0.5]);  % محدوده محور زمان را کمی بیشتر از زمان شبیه‌سازی نشان می‌دهد
	ylim([-0.2 1.0]);        % محدوده محور موقعیت را از -0.2 تا 1.0 متر تنظیم می‌کند
	
	% --- Formatting ---
	title('Dynamic Response with Fixed Beam Angle (from Simulink)');
	xlabel('Time (s)');
	ylabel('Ball Position r (m)');
	grid on;
	legend(plot_legends, 'Location', 'northwest');