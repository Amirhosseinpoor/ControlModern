
function dxdt = ball_beam_nonlinear_ode(t, x, params)
    % استخراج پارامترهای سیستم
    m = params.m;
    R = params.R;
    g = params.g;
    J_ball = params.J_ball;
    J_beam = params.J_beam;
    u = params.u; % ورودی سیستم

    % استخراج متغیرهای حالت
    r = x(1);
    r_dot = x(2);
    alpha = x(3);
    alpha_dot = x(4);

    % مقداردهی اولیه بردار مشتق حالت
    dxdt = zeros(4,1);

    % معادلات حالت غیرخطی
    dxdt(1) = r_dot;
    dxdt(2) = (m*r*alpha_dot^2 - m*g*sin(alpha)) / (m + J_ball/R^2);
    dxdt(3) = alpha_dot;
    dxdt(4) = (u - 2*m*r*r_dot*alpha_dot - m*g*r*cos(alpha)) / (J_beam + m*r^2);
end