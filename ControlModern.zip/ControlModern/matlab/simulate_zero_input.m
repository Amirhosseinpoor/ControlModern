
clear; clc; close all;


params.m = 0.11;    
params.R = 0.015;    
params.g = 9.8;       
params.L = 1.0;       
params.J_ball = 2/5 * params.m * params.R^2; % 
params.J_beam = 0.02;    

% ورودی سیستم (صفر برای این تحلیل)
params.u = 0;

% شرط اولیه 1: انحراف کوچک در موقعیت گوی
x0_1 = [0.1, 0, 0, 0]; 
% شرط اولیه 2: انحراف کوچک در زاویه میله
x0_2 = [0, 0, 0.05, 0]; % 
% شرط اولیه 3: ترکیبی
x0_3 = [0.1, 0, 0.05, 0];

% بازه زمانی شبیه‌سازی
t_span = [0 5];

% حل معادلات دیفرانسیل با ode45
[t1, x1] = ode45(@(t,x) ball_beam_nonlinear_ode(t, x, params), t_span, x0_1);
[t2, x2] = ode45(@(t,x) ball_beam_nonlinear_ode(t, x, params), t_span, x0_2);
[t3, x3] = ode45(@(t,x) ball_beam_nonlinear_ode(t, x, params), t_span, x0_3);

% رسم نتایج
figure('Name', 'Zero-Input Response of Nonlinear System');

% نمودار موقعیت گوی (r)
subplot(2,1,1);
plot(t1, x1(:,1), 'b-', 'LineWidth', 1.5); hold on;
plot(t2, x2(:,1), 'r--', 'LineWidth', 1.5);
plot(t3, x3(:,1), 'g-.', 'LineWidth', 1.5);
title('Ball Position (r) vs. Time');
xlabel('Time (s)');
ylabel('Position (m)');
legend('r(0)=0.1m', '\alpha(0)=0.05rad', 'r(0)=0.1, \alpha(0)=0.05');
grid on;
ylim([-params.L/2, params.L/2]); % محدود کردن محور y به طول میله

% نمودار زاویه میله (alpha)
subplot(2,1,2);
plot(t1, x1(:,3), 'b-', 'LineWidth', 1.5); hold on;
plot(t2, x2(:,3), 'r--', 'LineWidth', 1.5);
plot(t3, x3(:,3), 'g-.', 'LineWidth', 1.5);
title('Beam Angle (\alpha) vs. Time');
xlabel('Time (s)');
ylabel('Angle (rad)');
legend('r(0)=0.1m', '\alpha(0)=0.05rad', 'r(0)=0.1, \alpha(0)=0.05');
grid on;