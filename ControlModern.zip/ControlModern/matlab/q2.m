% Main script for DYNAMIC open-loop simulation
clear; clc; close all;

% --- System Parameters ---
params.m = 0.11;      % Mass of the ball (kg)
params.R = 0.015;     % Radius of the ball (m)
params.g = 9.8;       % Acceleration due to gravity (m/s^2)
params.J = 9.99e-6;   % Moment of inertia of the ball (kg*m^2)

% --- Simulation Time ---
tspan = [0 2.5]; % Shortened time to better see the dynamics

% --- Initial Conditions ---
% 1. Start from rest at the center
x0_1 = [0; 0]; 
% 2. Start at a positive position with zero velocity
x0_2 = [0.2; 0];
% 3. Start at the center with an initial "uphill" velocity
x0_3 = [0; 0.25];
% 4. Start at a positive position with an "uphill" velocity
x0_4 = [0.1; 0.1];

% --- Run Simulations ---
% Use the new dynamic ODE function for all simulations
ode_func = @(t,x) ball_beam_nl_ode(t,x,params);

[t1, x1] = ode45(ode_func, tspan, x0_1);
[t2, x2] = ode45(ode_func, tspan, x0_2);
[t3, x3] = ode45(ode_func, tspan, x0_3);
[t4, x4] = ode45(ode_func, tspan, x0_4);

% --- Plotting Results ---
figure('Name', 'Dynamic Response on a Fixed-Angle Beam');
hold on; % Draw all plots on the same axes

plot(t1, x1(:,1), 'b-', 'LineWidth', 2);
plot(t2, x2(:,1), 'r--', 'LineWidth', 2);
plot(t3, x3(:,1), 'g:', 'LineWidth', 3);
plot(t4, x4(:,1), 'k-.', 'LineWidth', 2);

hold off;

% --- Formatting ---
title('Dynamic Response with Fixed Beam Angle (\alpha = 0.05 rad)');
xlabel('Time (s)');
ylabel('Ball Position r (m)');
grid on;
legend(...
    'Start at rest: r(0)=0,  r_{dot}(0)=0', ...
    'Start at r=0.2, rest', ...
    'Uphill velocity: r_{dot}(0)=0.25', ...
    'Uphill velocity from r=0.1', ...
    'Location', 'northwest');