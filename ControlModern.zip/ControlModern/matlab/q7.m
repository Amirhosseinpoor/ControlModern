% Script to check controllability and observability of the linearized
% ball and beam system using different methods.
clear; clc; close all;
m = 0.111;
R = 0.015;
g = -9.8;
L = 1.0;
d = 0.03;
J = 9.99e-6;
% --- Step 1: Linearize the Simulink Model ---
model_name = 'ball'; % Ensure your Simulink file 'ball.slx' is in the path
fprintf('Linearizing Simulink model "%s"...\n', model_name);
try
    [A, B, C, D] = linmod(model_name);
catch ME
    error('Could not linearize the Simulink model. Make sure "%s.slx" is in the MATLAB path and the model can run.', model_name);
end

n = size(A, 1); % Number of states
fprintf('Linearization complete. System has %d states.\n\n', n);

fprintf('--- CONTROLLABILITY ANALYSIS ---\n');

% 1a. Rank Test using the Controllability Matrix
disp('1. Checking rank of the Controllability Matrix...');
Co = ctrb(A, B); % MATLAB's function to compute the controllability matrix
rank_Co = rank(Co);

fprintf('The controllability matrix Co is:\n');
disp(Co);
fprintf('The rank of Co is %d.\n', rank_Co);

if rank_Co == n
    fprintf('✅ RESULT: Since rank(Co) == n (%d), the system is CONTROLLABLE.\n\n', n);
else
    fprintf('❌ RESULT: Since rank(Co) != n (%d), the system is NOT CONTROLLABLE.\n\n', n);
end


% 1b. PBH Test
disp('2. Performing the PBH Test for Controllability...');
eigenvalues = eig(A);
is_controllable_pbh = true;

for i = 1:length(eigenvalues)
    s = eigenvalues(i);
    M = [s*eye(n) - A, B];
    rank_M = rank(M);
    fprintf('For eigenvalue s = %.4f, the rank of [sI-A, B] is %d.\n', s, rank_M);
    if rank_M < n
        is_controllable_pbh = false;
        break;
    end
end

if is_controllable_pbh
    fprintf('✅ RESULT: The PBH test confirms the system is CONTROLLABLE.\n\n');
else
    fprintf('❌ RESULT: The PBH test shows the system is NOT CONTROLLABLE.\n\n');
end


fprintf('--- OBSERVABILITY ANALYSIS ---\n');

% 2a. Rank Test using the Observability Matrix
disp('1. Checking rank of the Observability Matrix...');
Ob = obsv(A, C); % MATLAB's function to compute the observability matrix
rank_Ob = rank(Ob);

fprintf('The observability matrix Ob is:\n');
disp(Ob);
fprintf('The rank of Ob is %d.\n', rank_Ob);

if rank_Ob == n
    fprintf('✅ RESULT: Since rank(Ob) == n (%d), the system is OBSERVABLE.\n\n', n);
else
    fprintf('❌ RESULT: Since rank(Ob) != n (%d), the system is NOT OBSERVABLE.\n\n', n);
end


% 2b. PBH Test
disp('2. Performing the PBH Test for Observability...');
is_observable_pbh = true;

for i = 1:length(eigenvalues)
    s = eigenvalues(i);
    N_matrix = [s*eye(n) - A; C];
    rank_N = rank(N_matrix);
    fprintf('For eigenvalue s = %.4f, the rank of [sI-A; C] is %d.\n', s, rank_N);
    if rank_N < n
        is_observable_pbh = false;
        break;
    end
end

if is_observable_pbh
    fprintf('✅ RESULT: The PBH test confirms the system is OBSERVABLE.\n\n');
else
    fprintf('❌ RESULT: The PBH test shows the system is NOT OBSERVABLE.\n\n');
end


fprintf('--- JORDAN FORM ANALYSIS ---\n');
disp('Analyzing system using its Jordan Canonical Form...');
[P, J] = jordan(A); % P is the transformation matrix, J is the Jordan form

% Check for distinct eigenvalues, which implies a simple diagonal Jordan form
if length(unique(eigenvalues)) == n
    fprintf('The system has distinct eigenvalues, so its Jordan form is diagonal.\n');
    disp('J (Jordan Form of A) =');
    disp(J);

    % Transform B and C matrices
    B_j = P \ B;
    C_j = C * P;

    fprintf('Transformed B matrix (B_j = P^-1 * B):\n');
    disp(B_j);
    fprintf('Transformed C matrix (C_j = C * P):\n');
    disp(C_j);

    % For a diagonal Jordan form, controllability requires no rows of B_j are zero,
    % and observability requires no columns of C_j are zero.
    is_controllable_jordan = all(B_j ~= 0);
    is_observable_jordan = all(C_j ~= 0);

    if is_controllable_jordan
        fprintf('✅ Controllability: No row of B_j is zero. System is controllable.\n');
    else
        fprintf('❌ Controllability: At least one row of B_j is zero. System is not controllable.\n');
    end

    if is_observable_jordan
         fprintf('✅ Observability: No column of C_j is zero. System is observable.\n');
    else
        fprintf('❌ Observability: At least one column of C_j is zero. System is not observable.\n');
    end
else
    fprintf('The system has repeated eigenvalues. Manual inspection of the Jordan blocks and the transformed B and C matrices would be required for a definitive conclusion from this test.\n');
end